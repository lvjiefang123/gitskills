package com.aaa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.aaa.entity.tshoping;
import com.aaa.service.Shopingservice;
@Controller
@RequestMapping(value="/ts",produces="application/json;charset=utf-8")
public class ShopController {
	@Autowired
	private Shopingservice ser;
	
	@RequestMapping("/find")
	@ResponseBody
public List<tshoping> find(){
	List<tshoping> list=ser.find();
	return list;
	
}
@RequestMapping("/findById")
@ResponseBody
public  List<Map<String, Object>> findById(int tid){
	List<Map<String, Object>> g=ser.findById(tid);
	return g;
	
}
@RequestMapping("/update")
@ResponseBody
public String update(tshoping p,HttpServletResponse response) throws IOException{
	System.out.println(p);
	String text;
	int result=ser.update(p);
	System.out.println(result+"action0000000000000000000000000000");
	if (result>0) {
		text="�ɹ�";
	}else {
		text="�޸�ʧ��";
	}
	return text;
}
@RequestMapping("/save")
public void save( tshoping p,HttpServletResponse response) throws IOException{
	
	response.setContentType("text/html;charset=utf-8");
	PrintWriter out =response.getWriter();
	int result=ser.save(p);
	if (result!=0) {
		out.print("���ӳɹ�");
	}else {
		out.print("����ʧ��");
	}	
	
}
@RequestMapping("/delete")
@ResponseBody
public void delete(int tid,HttpServletResponse response) throws IOException{
	response.setContentType("text/html;charset=utf-8");
	PrintWriter out =response.getWriter();
	int result=ser.delete(tid);
	if (result!=0) {
		out.print("ɾ���ɹ�");
	}else {
		out.print("ɾ��ʧ��");
	}
}

}
