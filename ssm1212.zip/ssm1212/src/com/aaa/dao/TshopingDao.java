package com.aaa.dao;

import java.util.List;
import java.util.Map;

import com.aaa.entity.tshoping;

public interface TshopingDao {
public List<tshoping> find();
public List<Map<String, Object>> findById(int tid);
public int update(tshoping p);
public int save(tshoping p);
public int delete(int tid);
}
