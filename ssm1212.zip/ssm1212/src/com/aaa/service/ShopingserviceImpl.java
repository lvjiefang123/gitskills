package com.aaa.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aaa.dao.TshopingDao;
import com.aaa.entity.tshoping;
@Service
public class ShopingserviceImpl implements Shopingservice{
@Autowired
private TshopingDao dao;
	@Override
	public List<tshoping> find() {
		// TODO Auto-generated method stub
		return dao.find();
	}
	@Override
	public List<Map<String, Object>> findById(int tid) {
		// TODO Auto-generated method stub
		return dao.findById(tid);
	}
	@Override
	public int update(tshoping p) {
		// TODO Auto-generated method stub
		return dao.update(p);
	}
	@Override
	public int save(tshoping p) {
		// TODO Auto-generated method stub
		return dao.save(p);
	}
	@Override
	public int delete(int tid) {
		// TODO Auto-generated method stub
		return dao.delete(tid);
	}
	

}
